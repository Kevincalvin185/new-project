# Savings platform backend

Node 20+ API: user accounts (email or Ugandan phone) with OTP verification, a double-entry ledger in SQLite, fixed-term plans with simple interest, a manual mobile-money deposit and payout queue, and a private admin API.

## Setup
1. `npm install`
2. `cp .env.example .env`, then fill in:
   - `JWT_SECRET`: `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`
   - `ADMIN_USER` and `ADMIN_PASS_HASH` (from `npm run hash -- "your-long-admin-password"`)
   - `PLATFORM_NAME` and `LOGO_URL` (placeholders; served by `GET /api/config` so the web and phone front ends show the same brand)
   - `PAY_NUMBER`: your collection/payout mobile money number (placeholder until you set it)
3. `npm start`

`DEPOSITS_ENABLED=false` (default) makes `POST /api/deposits` return 403, so no real money can be recorded. Turn it on only after licensing is settled and OTP delivery works.

## How money moves
- User sends mobile money to `PAY_NUMBER`, submits the transaction ID (`POST /api/deposits`) and the deposit sits as pending.
- Admin checks the statement and confirms (`POST /api/admin/deposits/:id/confirm`). Only then is the wallet credited (Dr BANK, Cr WALLET).
- Invest (`POST /api/invest`). At maturity, principal plus interest is credited to the wallet automatically (a background job runs every minute, and balances settle whenever a user loads their dashboard, invests or withdraws), so it is immediately withdrawable via `POST /api/withdrawals`. `POST /api/investments/:id/collect` is now only for early withdrawal.
- Admin sends the money from `PAY_NUMBER`, then records the payout transaction ID (`POST /api/admin/withdrawals/:id/paid`).
- `GET /api/admin/reconcile` shows whether the ledger balances, your book cash position, and `fundingGap`: interest owed beyond the cash from deposits. That gap must come from real income, not from other users' deposits.

## Referral program (single level)
- Each user gets a referral code; sign-up accepts an optional `referralCode`. The referrer is fixed at sign-up and self-referral is blocked.
- A commission (`REFERRAL_BPS`, capped by `REFERRAL_CAP`) is created only when a referee's first plan of `REFERRAL_MIN_DAYS` or longer matures. Early withdrawals and short plans never qualify. One commission per referee.
- The commission waits as pending until you approve it in admin (`POST /api/admin/referrals/:id/approve`), which credits the referrer's wallet (Dr REFERRAL_EXPENSE, Cr WALLET). Only direct referrals earn; nothing is paid on a referral's own referrals.
- Referral links: set `APP_URL` in `.env`; `GET /api/me` then returns `referral.link` (`APP_URL/?ref=CODE`). The web app reads `?ref=` on load and pre-fills the sign-up referral code; share buttons (WhatsApp, Telegram, SMS, email, copy, native share sheet) use that link.
- Users see their code, masked referrals and earnings in `GET /api/me` (`referral`). Admin sees links and commissions at `/api/admin/referral-links` and `/api/admin/referrals`.
- Commissions are a marketing cost and increase `fundingGap` in reconcile; fund them from real income.

## Endpoints
User: `register`, `verify`, `login`, `logout`, `me`, `plans`, `deposits`, `invest`, `investments/:id/collect`, `withdrawals`.
Admin (all under `/api/admin`, separate cookie): `login`, `logout`, `summary`, `deposits`, `withdrawals`, `deposits/:id/confirm|reject`, `withdrawals/:id/paid`, `ledger`, `audit`, `reconcile`.

## Before going live
- Implement `sendOtp()` (email provider and/or Africa's Talking SMS). In production it refuses to run without one.
- Serve over HTTPS and set `NODE_ENV=production` (secure cookies, trusted proxy).
- Edit the placeholder plans (seeded in `server.js`: days, minimum UGX, interest in basis points).
- Back up `data.db` regularly and keep it off the public web root.
- Use a registered business or merchant mobile money account rather than a personal wallet.
- Settle the licensing question first. This code does not make deposit-taking legal.

## Test
`test/smoke.js` runs the full flow against a running test server (see the commands used to build it: start with `DEPOSITS_ENABLED=true DB_FILE=test.db`).
