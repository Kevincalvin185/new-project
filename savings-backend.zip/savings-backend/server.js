"use strict";
const express = require("express"), Database = require("better-sqlite3"), bcrypt = require("bcryptjs"),
  jwt = require("jsonwebtoken"), crypto = require("crypto"), helmet = require("helmet"), rateLimit = require("express-rate-limit");

const { JWT_SECRET, ADMIN_USER, ADMIN_PASS_HASH, PAY_NUMBER = "07XX XXX XXX", PLATFORM_NAME = "Your Platform Name", LOGO_URL = "", DB_FILE = "data.db", NODE_ENV } = process.env;
const PORT = process.env.PORT || 3000, DEPOSITS_ON = process.env.DEPOSITS_ENABLED === "true", PROD = NODE_ENV === "production";
if (!JWT_SECRET || JWT_SECRET.length < 32) throw new Error("Set JWT_SECRET (32+ characters) in .env");
// Single-level referral: one-time commission on the referee's first qualifying investment, paid only after it matures and admin approves.
const REF_BPS = Number(process.env.REFERRAL_BPS ?? 100), REF_CAP = Number(process.env.REFERRAL_CAP ?? 20000), REF_MIN_DAYS = Number(process.env.REFERRAL_MIN_DAYS ?? 30);
const REF = { percent: REF_BPS / 100, capUGX: REF_CAP, minDays: REF_MIN_DAYS };
const APP_URL = (process.env.APP_URL || "").replace(/\/$/, ""); // public address of your web app, used to build referral links

// ---------- Database (all money is stored as whole UGX integers) ----------
const db = new Database(DB_FILE);
db.pragma("journal_mode=WAL"); db.pragma("foreign_keys=ON");
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,kind TEXT NOT NULL,contact TEXT UNIQUE NOT NULL,pw_hash TEXT NOT NULL,verified INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS otps(contact TEXT PRIMARY KEY,code_hash TEXT NOT NULL,expires INTEGER NOT NULL,attempts INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS plans(id INTEGER PRIMARY KEY,days INTEGER UNIQUE NOT NULL,min_amount INTEGER NOT NULL,rate_bps INTEGER NOT NULL,active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS entries(id INTEGER PRIMARY KEY,ts INTEGER NOT NULL,description TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS lines(id INTEGER PRIMARY KEY,entry_id INTEGER NOT NULL REFERENCES entries(id),account TEXT NOT NULL,user_id INTEGER,debit INTEGER NOT NULL DEFAULT 0,credit INTEGER NOT NULL DEFAULT 0,CHECK(debit>=0 AND credit>=0));
CREATE TABLE IF NOT EXISTS investments(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),days INTEGER NOT NULL,amount INTEGER NOT NULL,interest INTEGER NOT NULL,start_ts INTEGER NOT NULL,maturity_ts INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'active');
CREATE TABLE IF NOT EXISTS deposits(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),amount INTEGER NOT NULL,ref TEXT UNIQUE NOT NULL,status TEXT NOT NULL DEFAULT 'pending',created_at INTEGER NOT NULL,decided_at INTEGER);
CREATE TABLE IF NOT EXISTS withdrawals(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),amount INTEGER NOT NULL,network TEXT NOT NULL,phone TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',ref TEXT,created_at INTEGER NOT NULL,decided_at INTEGER);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,ts INTEGER NOT NULL,actor TEXT NOT NULL,action TEXT NOT NULL,detail TEXT);
CREATE INDEX IF NOT EXISTS idx_lines_acct ON lines(account,user_id);
`);
const ucols = db.prepare("PRAGMA table_info(users)").all().map(c => c.name);
if (!ucols.includes("ref_code")) db.exec("ALTER TABLE users ADD COLUMN ref_code TEXT");
if (!ucols.includes("referred_by")) db.exec("ALTER TABLE users ADD COLUMN referred_by INTEGER");
db.exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_users_refcode ON users(ref_code);
CREATE TABLE IF NOT EXISTS referral_commissions(id INTEGER PRIMARY KEY,referrer_id INTEGER NOT NULL REFERENCES users(id),referee_id INTEGER NOT NULL UNIQUE REFERENCES users(id),investment_id INTEGER NOT NULL,amount INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'pending',created_at INTEGER NOT NULL,decided_at INTEGER);`);
const ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const newCode = () => { for (;;) { const c = Array.from(crypto.randomBytes(8), b => ALPHA[b % ALPHA.length]).join(""); if (!db.prepare("SELECT 1 FROM users WHERE ref_code=?").get(c)) return c; } };
for (const u of db.prepare("SELECT id FROM users WHERE ref_code IS NULL").all()) db.prepare("UPDATE users SET ref_code=? WHERE id=?").run(newCode(), u.id);
if (!db.prepare("SELECT COUNT(*) n FROM plans").get().n) { // PLACEHOLDER plans: [days, minimum UGX, interest for the term in basis points]. Edit before launch.
  const ins = db.prepare("INSERT INTO plans(days,min_amount,rate_bps) VALUES(?,?,?)");
  [[5, 20000, 20], [10, 25000, 40], [15, 30000, 60], [30, 50000, 120], [45, 75000, 190], [60, 100000, 260],
   [90, 150000, 400], [120, 200000, 560], [150, 250000, 720], [180, 300000, 900]].forEach(p => ins.run(...p));
}

// ---------- Double-entry ledger ----------
class HttpErr extends Error { constructor(code, msg) { super(msg); this.code = code; } }
function post(desc, ls) {
  const d = ls.reduce((a, l) => a + (l.dr || 0), 0), c = ls.reduce((a, l) => a + (l.cr || 0), 0);
  if (d !== c || d <= 0) throw new Error("Unbalanced ledger entry");
  const id = db.prepare("INSERT INTO entries(ts,description) VALUES(?,?)").run(Date.now(), desc).lastInsertRowid;
  const ins = db.prepare("INSERT INTO lines(entry_id,account,user_id,debit,credit) VALUES(?,?,?,?,?)");
  for (const l of ls) ins.run(id, l.acct, l.uid ?? null, l.dr || 0, l.cr || 0);
}
// Liability accounts (WALLET, INVESTED, PAYOUT_PENDING): credit minus debit. BANK and INTEREST_EXPENSE: debit minus credit.
const liab = (acct, uid) => db.prepare("SELECT COALESCE(SUM(credit-debit),0) b FROM lines WHERE account=? AND user_id IS ?").get(acct, uid ?? null).b;
const asset = acct => db.prepare("SELECT COALESCE(SUM(debit-credit),0) b FROM lines WHERE account=?").get(acct).b;
const audit = (actor, action, detail) => db.prepare("INSERT INTO audit(ts,actor,action,detail) VALUES(?,?,?,?)").run(Date.now(), actor, action, detail ? JSON.stringify(detail) : null);

// ---------- Helpers ----------
const sha = s => crypto.createHash("sha256").update(s).digest("hex");
const normContact = raw => {
  raw = String(raw || "").trim();
  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(raw)) return { kind: "email", contact: raw.toLowerCase() };
  const m = raw.replace(/[\s\-()]/g, "").match(/^(?:\+?256|0)([37]\d{8})$/);
  return m ? { kind: "phone", contact: "+256" + m[1] } : null;
};
const normPhone = raw => { const c = normContact(raw); return c && c.kind === "phone" ? c.contact : null; };
const money = v => (Number.isInteger(v) && v > 0 && v <= 1e10 ? v : null);
const cookies = req => Object.fromEntries((req.headers.cookie || "").split(";").map(c => c.trim().split("=")).filter(c => c[0]).map(([k, ...v]) => [k, decodeURIComponent(v.join("="))]));
const setCookie = (res, name, tok, maxAge) => res.append("Set-Cookie", `${name}=${tok}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAge}${PROD ? "; Secure" : ""}`);
const who = (req, name) => { try { return jwt.verify(cookies(req)[name], JWT_SECRET); } catch { return null; } };
const userAuth = (req, res, next) => { const t = who(req, "sid"); if (!t || t.role !== "user") return res.status(401).json({ error: "Sign in required" }); req.uid = t.uid; next(); };
const adminAuth = (req, res, next) => { const t = who(req, "aid"); if (!t || t.role !== "admin") return res.status(401).json({ error: "Admin sign-in required" }); req.admin = t.sub; next(); };
const h = fn => (req, res) => { try { res.json(fn(req, res)); } catch (e) { if (e instanceof HttpErr) return res.status(e.code).json({ error: e.message }); console.error(e); res.status(500).json({ error: "Server error" }); } };
async function sendOtp(c, code) {
  if (!PROD) { console.log(`[DEV OTP] ${c.contact}: ${code}`); return; }
  // TODO: plug in an email provider (c.kind==="email") or an SMS provider such as Africa's Talking (c.kind==="phone").
  throw new Error("Configure OTP delivery in sendOtp() before running in production");
}

// Matured investments are credited to the wallet automatically (status 'paid' = principal + interest credited).
const settleDue = db.transaction(uid => {
  const rows = uid ? db.prepare("SELECT * FROM investments WHERE status='active' AND maturity_ts<=? AND user_id=?").all(Date.now(), uid)
                   : db.prepare("SELECT * FROM investments WHERE status='active' AND maturity_ts<=?").all(Date.now());
  for (const i of rows) {
    post(`Maturity payout #${i.id}`, [{ acct: "INVESTED", uid: i.user_id, dr: i.amount }, { acct: "INTEREST_EXPENSE", dr: i.interest }, { acct: "WALLET", uid: i.user_id, cr: i.amount + i.interest }]);
    db.prepare("UPDATE investments SET status='paid' WHERE id=?").run(i.id);
    const ru = db.prepare("SELECT referred_by FROM users WHERE id=?").get(i.user_id);
    if (ru && ru.referred_by && i.days >= REF_MIN_DAYS && REF_BPS > 0) { // first qualifying investment to mature, one commission per referee
      const amt = Math.min(Math.floor(i.amount * REF_BPS / 10000), REF_CAP);
      if (amt > 0) db.prepare("INSERT OR IGNORE INTO referral_commissions(referrer_id,referee_id,investment_id,amount,created_at) VALUES(?,?,?,?,?)").run(ru.referred_by, i.user_id, i.id, amt, Date.now());
    }
  }
  return rows.length;
});
setInterval(() => { try { settleDue(); } catch (e) { console.error("settle failed", e); } }, 60000).unref();

const mask = c => (c.length <= 5 ? "***" : c.slice(0, 3) + "***" + c.slice(-2));
function referralInfo(uid) {
  const u = db.prepare("SELECT ref_code FROM users WHERE id=?").get(uid);
  const refs = db.prepare(`SELECT u.contact,u.created_at createdAt,
    (SELECT COUNT(*) FROM investments i WHERE i.user_id=u.id) invCount,
    (SELECT status FROM referral_commissions c WHERE c.referee_id=u.id) commission,
    (SELECT amount FROM referral_commissions c WHERE c.referee_id=u.id) commissionAmount
    FROM users u WHERE u.referred_by=? AND u.verified=1 ORDER BY u.id DESC`).all(uid);
  const sum = st => db.prepare("SELECT COALESCE(SUM(amount),0) t FROM referral_commissions WHERE referrer_id=? AND status=?").get(uid, st).t;
  return { code: u.ref_code, link: APP_URL ? `${APP_URL}/?ref=${u.ref_code}` : null, terms: REF, earned: sum("approved"), pending: sum("pending"),
    referrals: refs.map(r => ({ contact: mask(r.contact), createdAt: r.createdAt, invested: r.invCount > 0, commission: r.commission || null, commissionAmount: r.commissionAmount || 0 })) };
}

// ---------- App ----------
const app = express();
if (PROD) app.set("trust proxy", 1); // set to the number of proxies in front of the app
app.use(helmet()); app.use(express.json({ limit: "10kb" }));
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false });
const adminLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 5, standardHeaders: true, legacyHeaders: false });

// --- Accounts ---
app.post("/api/register", authLimiter, async (req, res) => {
  const c = normContact(req.body.contact), pw = String(req.body.password || "");
  if (!c) return res.status(400).json({ error: "Enter a valid email or Ugandan phone number" });
  if (pw.length < 8) return res.status(400).json({ error: "Password must be at least 8 characters" });
  const ex = db.prepare("SELECT id,verified FROM users WHERE contact=?").get(c.contact);
  if (ex && ex.verified) return res.status(409).json({ error: "Account already exists. Sign in instead." });
  let refBy = null; const rc = String(req.body.referralCode || "").trim().toUpperCase();
  if (rc) { // one referrer, fixed at sign-up; no self-referral
    const r = db.prepare("SELECT id,contact FROM users WHERE ref_code=? AND verified=1").get(rc);
    if (!r || r.contact === c.contact) return res.status(400).json({ error: "Invalid referral code" });
    refBy = r.id;
  }
  const hash = await bcrypt.hash(pw, 12);
  if (ex) db.prepare("UPDATE users SET pw_hash=?,referred_by=COALESCE(referred_by,?) WHERE id=?").run(hash, refBy, ex.id);
  else db.prepare("INSERT INTO users(kind,contact,pw_hash,created_at,ref_code,referred_by) VALUES(?,?,?,?,?,?)").run(c.kind, c.contact, hash, Date.now(), newCode(), refBy);
  const code = String(crypto.randomInt(100000, 1000000));
  db.prepare("INSERT OR REPLACE INTO otps(contact,code_hash,expires,attempts) VALUES(?,?,?,0)").run(c.contact, sha(code), Date.now() + 10 * 60000);
  try { await sendOtp(c, code); } catch (e) { console.error(e.message); return res.status(503).json({ error: "Could not send verification code" }); }
  res.json({ ok: true });
});
app.post("/api/verify", authLimiter, (req, res) => {
  const c = normContact(req.body.contact), code = String(req.body.code || "");
  const o = c && db.prepare("SELECT * FROM otps WHERE contact=?").get(c.contact);
  if (!o || o.expires < Date.now() || o.attempts >= 5) return res.status(400).json({ error: "Code expired. Register again to get a new code." });
  db.prepare("UPDATE otps SET attempts=attempts+1 WHERE contact=?").run(c.contact);
  if (!crypto.timingSafeEqual(Buffer.from(o.code_hash), Buffer.from(sha(code)))) return res.status(400).json({ error: "Incorrect code" });
  db.prepare("UPDATE users SET verified=1 WHERE contact=?").run(c.contact); db.prepare("DELETE FROM otps WHERE contact=?").run(c.contact);
  const u = db.prepare("SELECT id FROM users WHERE contact=?").get(c.contact);
  setCookie(res, "sid", jwt.sign({ role: "user", uid: u.id }, JWT_SECRET, { expiresIn: "7d" }), 7 * 86400);
  res.json({ ok: true });
});
app.post("/api/login", authLimiter, async (req, res) => {
  const c = normContact(req.body.contact), u = c && db.prepare("SELECT * FROM users WHERE contact=? AND verified=1").get(c.contact);
  if (!u || !(await bcrypt.compare(String(req.body.password || ""), u.pw_hash))) return res.status(401).json({ error: "Wrong contact or password" });
  setCookie(res, "sid", jwt.sign({ role: "user", uid: u.id }, JWT_SECRET, { expiresIn: "7d" }), 7 * 86400);
  res.json({ ok: true });
});
app.post("/api/logout", (req, res) => { setCookie(res, "sid", "", 0); res.json({ ok: true }); });

// --- Public / user data ---
app.get("/api/config", (req, res) => res.json({ name: PLATFORM_NAME, logoUrl: LOGO_URL, depositsEnabled: DEPOSITS_ON, referral: REF }));
app.get("/api/plans", (req, res) => res.json(db.prepare("SELECT id,days,min_amount minAmount,rate_bps rateBps FROM plans WHERE active=1 ORDER BY days").all()));
app.get("/api/me", userAuth, h(req => {
  settleDue(req.uid);
  const u = db.prepare("SELECT contact,kind FROM users WHERE id=?").get(req.uid);
  return { ...u, referral: referralInfo(req.uid), wallet: liab("WALLET", req.uid), invested: liab("INVESTED", req.uid), depositsEnabled: DEPOSITS_ON, payNumber: DEPOSITS_ON ? PAY_NUMBER : null,
    investments: db.prepare("SELECT * FROM investments WHERE user_id=? ORDER BY id DESC").all(req.uid),
    deposits: db.prepare("SELECT id,amount,ref,status,created_at createdAt FROM deposits WHERE user_id=? ORDER BY id DESC").all(req.uid),
    withdrawals: db.prepare("SELECT id,amount,network,phone,status,ref,created_at createdAt FROM withdrawals WHERE user_id=? ORDER BY id DESC").all(req.uid) };
}));

// --- Money actions (each runs in one SQL transaction) ---
app.post("/api/deposits", userAuth, h(db.transaction(req => {
  if (!DEPOSITS_ON) throw new HttpErr(403, "Deposits are not open yet");
  const a = money(req.body.amount), ref = String(req.body.ref || "").trim().toUpperCase();
  if (!a) throw new HttpErr(400, "Enter a valid amount");
  if (!/^[A-Z0-9]{6,30}$/.test(ref)) throw new HttpErr(400, "Enter the mobile money transaction ID");
  try { return { id: db.prepare("INSERT INTO deposits(user_id,amount,ref,created_at) VALUES(?,?,?,?)").run(req.uid, a, ref, Date.now()).lastInsertRowid }; }
  catch { throw new HttpErr(409, "That transaction ID was already submitted"); }
})));
app.post("/api/invest", userAuth, h(db.transaction(req => {
  settleDue(req.uid);
  const a = money(req.body.amount), p = db.prepare("SELECT * FROM plans WHERE id=? AND active=1").get(req.body.planId);
  if (!p) throw new HttpErr(400, "Unknown plan");
  if (!a || a < p.min_amount) throw new HttpErr(400, `Minimum for this plan is UGX ${p.min_amount.toLocaleString("en-US")}`);
  if (a > liab("WALLET", req.uid)) throw new HttpErr(400, "Not enough wallet balance");
  const now = Date.now(), interest = Math.floor(a * p.rate_bps / 10000);
  post(`Invest in ${p.days}-day plan`, [{ acct: "WALLET", uid: req.uid, dr: a }, { acct: "INVESTED", uid: req.uid, cr: a }]);
  return { id: db.prepare("INSERT INTO investments(user_id,days,amount,interest,start_ts,maturity_ts) VALUES(?,?,?,?,?,?)").run(req.uid, p.days, a, interest, now, now + p.days * 86400000).lastInsertRowid };
})));
app.post("/api/investments/:id/collect", userAuth, h(db.transaction(req => {
  settleDue(req.uid); // matured plans are settled automatically; this endpoint is for early withdrawal only
  const i = db.prepare("SELECT * FROM investments WHERE id=? AND user_id=?").get(req.params.id, req.uid);
  if (!i || i.status !== "active") throw new HttpErr(404, "Investment not found");
  if (req.body.confirmEarly !== true) throw new HttpErr(400, "Not matured yet. Send confirmEarly:true to withdraw principal only and forfeit the interest.");
  post(`Early withdrawal #${i.id} (interest forfeited)`, [{ acct: "INVESTED", uid: req.uid, dr: i.amount }, { acct: "WALLET", uid: req.uid, cr: i.amount }]);
  db.prepare("UPDATE investments SET status='early' WHERE id=?").run(i.id); return { paid: i.amount };
})));
app.post("/api/withdrawals", userAuth, h(db.transaction(req => {
  settleDue(req.uid);
  const a = money(req.body.amount), phone = normPhone(req.body.phone), net = ["MTN", "Airtel"].includes(req.body.network) ? req.body.network : null;
  if (!a || !phone || !net) throw new HttpErr(400, "Enter an amount, a valid Ugandan mobile money number and the network");
  if (a > liab("WALLET", req.uid)) throw new HttpErr(400, "Not enough wallet balance");
  const id = db.prepare("INSERT INTO withdrawals(user_id,amount,network,phone,created_at) VALUES(?,?,?,?,?)").run(req.uid, a, net, phone, Date.now()).lastInsertRowid;
  post(`Withdrawal request #${id}`, [{ acct: "WALLET", uid: req.uid, dr: a }, { acct: "PAYOUT_PENDING", uid: req.uid, cr: a }]);
  return { id };
})));

// --- Private admin (separate login and cookie; credentials come from .env, never the database) ---
app.post("/api/admin/login", adminLimiter, async (req, res) => {
  const okUser = ADMIN_USER && ADMIN_PASS_HASH && String(req.body.username || "") === ADMIN_USER;
  const okPass = await bcrypt.compare(String(req.body.password || ""), ADMIN_PASS_HASH || "$2a$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalidi");
  if (!okUser || !okPass) { audit("unknown", "admin_login_failed"); return res.status(401).json({ error: "Wrong credentials" }); }
  setCookie(res, "aid", jwt.sign({ role: "admin", sub: ADMIN_USER }, JWT_SECRET, { expiresIn: "8h" }), 8 * 3600);
  audit(ADMIN_USER, "admin_login"); res.json({ ok: true });
});
app.post("/api/admin/logout", (req, res) => { setCookie(res, "aid", "", 0); res.json({ ok: true }); });
app.get("/api/admin/summary", adminAuth, h(() => {
  const s = (t, st) => db.prepare(`SELECT COUNT(*) n,COALESCE(SUM(amount),0) total FROM ${t} WHERE status=?`).get(st);
  return { users: db.prepare("SELECT COUNT(*) n FROM users WHERE verified=1").get().n, payNumber: PAY_NUMBER, depositsEnabled: DEPOSITS_ON,
    pendingDeposits: s("deposits", "pending"), pendingWithdrawals: s("withdrawals", "pending"),
    pendingCommissions: db.prepare("SELECT COUNT(*) n,COALESCE(SUM(amount),0) total FROM referral_commissions WHERE status='pending'").get() };
}));
app.get("/api/admin/deposits", adminAuth, h(req => db.prepare("SELECT d.*,u.contact FROM deposits d JOIN users u ON u.id=d.user_id WHERE (?='' OR d.status=?) ORDER BY d.id DESC LIMIT 500").all(String(req.query.status || ""), String(req.query.status || ""))));
app.get("/api/admin/withdrawals", adminAuth, h(req => db.prepare("SELECT w.*,u.contact FROM withdrawals w JOIN users u ON u.id=w.user_id WHERE (?='' OR w.status=?) ORDER BY w.id DESC LIMIT 500").all(String(req.query.status || ""), String(req.query.status || ""))));
app.post("/api/admin/deposits/:id/confirm", adminAuth, h(db.transaction(req => {
  const d = db.prepare("SELECT * FROM deposits WHERE id=?").get(req.params.id);
  if (!d || d.status !== "pending") throw new HttpErr(404, "No pending deposit with that ID");
  post(`Deposit #${d.id} confirmed (ref ${d.ref})`, [{ acct: "BANK", dr: d.amount }, { acct: "WALLET", uid: d.user_id, cr: d.amount }]);
  db.prepare("UPDATE deposits SET status='confirmed',decided_at=? WHERE id=?").run(Date.now(), d.id); audit(req.admin, "deposit_confirmed", { id: d.id, amount: d.amount, ref: d.ref }); return { ok: true };
})));
app.post("/api/admin/deposits/:id/reject", adminAuth, h(req => {
  const r = db.prepare("UPDATE deposits SET status='rejected',decided_at=? WHERE id=? AND status='pending'").run(Date.now(), req.params.id);
  if (!r.changes) throw new HttpErr(404, "No pending deposit with that ID"); audit(req.admin, "deposit_rejected", { id: req.params.id }); return { ok: true };
}));
app.post("/api/admin/withdrawals/:id/paid", adminAuth, h(db.transaction(req => {
  const w = db.prepare("SELECT * FROM withdrawals WHERE id=?").get(req.params.id), ref = String(req.body.ref || "").trim().toUpperCase();
  if (!w || w.status !== "pending") throw new HttpErr(404, "No pending withdrawal with that ID");
  if (!/^[A-Z0-9]{6,30}$/.test(ref)) throw new HttpErr(400, "Enter the mobile money transaction ID of the payout");
  post(`Payout #${w.id} sent via ${w.network} (ref ${ref})`, [{ acct: "PAYOUT_PENDING", uid: w.user_id, dr: w.amount }, { acct: "BANK", cr: w.amount }]);
  db.prepare("UPDATE withdrawals SET status='paid',ref=?,decided_at=? WHERE id=?").run(ref, Date.now(), w.id); audit(req.admin, "withdrawal_paid", { id: w.id, amount: w.amount, ref }); return { ok: true };
})));
app.get("/api/admin/referral-links", adminAuth, h(() => db.prepare("SELECT u.id,u.contact referee,r.contact referrer,u.created_at createdAt FROM users u JOIN users r ON r.id=u.referred_by ORDER BY u.id DESC LIMIT 500").all()));
app.get("/api/admin/referrals", adminAuth, h(() => db.prepare("SELECT c.*,r.contact referrer,e.contact referee FROM referral_commissions c JOIN users r ON r.id=c.referrer_id JOIN users e ON e.id=c.referee_id ORDER BY c.id DESC LIMIT 500").all()));
app.post("/api/admin/referrals/:id/approve", adminAuth, h(db.transaction(req => {
  const c = db.prepare("SELECT * FROM referral_commissions WHERE id=?").get(req.params.id);
  if (!c || c.status !== "pending") throw new HttpErr(404, "No pending commission with that ID");
  post(`Referral commission #${c.id}`, [{ acct: "REFERRAL_EXPENSE", dr: c.amount }, { acct: "WALLET", uid: c.referrer_id, cr: c.amount }]);
  db.prepare("UPDATE referral_commissions SET status='approved',decided_at=? WHERE id=?").run(Date.now(), c.id);
  audit(req.admin, "commission_approved", { id: c.id, amount: c.amount }); return { ok: true };
})));
app.post("/api/admin/referrals/:id/reject", adminAuth, h(req => {
  const r = db.prepare("UPDATE referral_commissions SET status='rejected',decided_at=? WHERE id=? AND status='pending'").run(Date.now(), req.params.id);
  if (!r.changes) throw new HttpErr(404, "No pending commission with that ID"); audit(req.admin, "commission_rejected", { id: req.params.id }); return { ok: true };
}));
app.get("/api/admin/ledger", adminAuth, h(() => db.prepare("SELECT e.id,e.ts,e.description,l.account,l.user_id userId,l.debit,l.credit FROM entries e JOIN lines l ON l.entry_id=e.id ORDER BY e.id DESC,l.id LIMIT 600").all()));
app.get("/api/admin/audit", adminAuth, h(() => db.prepare("SELECT * FROM audit ORDER BY id DESC LIMIT 300").all()));
app.get("/api/admin/reconcile", adminAuth, h(() => {
  const t = db.prepare("SELECT COALESCE(SUM(debit),0) d,COALESCE(SUM(credit),0) c FROM lines").get();
  const owed = ["WALLET", "INVESTED", "PAYOUT_PENDING"].reduce((s, a) => s - asset(a), 0), bank = asset("BANK");
  return { balanced: t.d === t.c, totalDebits: t.d, totalCredits: t.c, bankBook: bank, owedToUsers: owed, interestAccrued: asset("INTEREST_EXPENSE"), referralCommissions: asset("REFERRAL_EXPENSE"),
    fundingGap: Math.max(0, owed - bank),
    note: "bankBook is deposits received minus payouts sent. Compare it with your real mobile money balance. fundingGap is what you owe users beyond the cash from their deposits (interest). It must be covered from real income such as loan repayments." };
}));

app.use((req, res) => res.status(404).json({ error: "Not found" }));
if (require.main === module) app.listen(PORT, () => console.log(`Savings backend on :${PORT} (deposits ${DEPOSITS_ON ? "ON" : "OFF"}, ${PROD ? "production" : "dev"})`));
module.exports = app;
