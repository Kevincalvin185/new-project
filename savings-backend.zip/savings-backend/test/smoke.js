// End-to-end smoke test. Run via: npm run test:smoke (starts its own server) or see README.
const fs = require("fs"), Database = require("better-sqlite3");
const B = process.env.BASE || "http://localhost:3399", jar = {};
async function api(method, path, body, who = "u") {
  const r = await fetch(B + path, { method, headers: { "content-type": "application/json", cookie: jar[who] || "" }, body: body ? JSON.stringify(body) : undefined });
  const sc = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
  if (sc.length) jar[who] = sc.map(c => c.split(";")[0]).join("; ");
  let j = {}; try { j = await r.json(); } catch {}
  return { s: r.status, j };
}
const ok = (c, m) => { if (!c) { console.error("FAIL:", m); process.exit(1); } console.log("ok  ", m); };
const otp = () => fs.readFileSync("server.log", "utf8").split("\n").filter(x => x.includes("[DEV OTP]")).pop().split(": ").pop().trim();
(async () => {
  let r = await api("POST", "/api/register", { contact: "0772 123 456", password: "correct horse" }); ok(r.s === 200, "register");
  r = await api("POST", "/api/verify", { contact: "0772123456", code: "000000" }); ok(r.s === 400, "wrong OTP rejected");
  r = await api("POST", "/api/verify", { contact: "0772123456", code: otp() }); ok(r.s === 200, "verify OTP, session cookie set");
  r = await api("GET", "/api/me"); ok(r.s === 200 && r.j.wallet === 0 && r.j.contact === "+256772123456", "me: empty wallet, normalised phone");
  r = await api("GET", "/api/admin/summary"); ok(r.s === 401, "user session cannot reach admin API");
  const plans = (await api("GET", "/api/plans")).j, p5 = plans.find(p => p.days === 5); ok(p5 && p5.minAmount === 20000, "plans listed, 5-day min 20,000");
  r = await api("POST", "/api/invest", { planId: p5.id, amount: 20000 }); ok(r.s === 400, "cannot invest with empty wallet");
  r = await api("POST", "/api/deposits", { amount: 100000, ref: "tx12345678" }); ok(r.s === 200, "deposit submitted (pending)");
  r = await api("POST", "/api/deposits", { amount: 5000, ref: "TX12345678" }); ok(r.s === 409, "duplicate transaction ID rejected");
  r = await api("POST", "/api/admin/login", { username: "kevin", password: "wrong-password-here" }, "a"); ok(r.s === 401, "bad admin password rejected");
  r = await api("POST", "/api/admin/login", { username: "kevin", password: "admin-test-password-123" }, "a"); ok(r.s === 200, "admin login");
  r = await api("GET", "/api/admin/deposits?status=pending", null, "a"); ok(r.s === 200 && r.j.length === 1, "admin sees pending deposit");
  r = await api("POST", "/api/admin/deposits/" + r.j[0].id + "/confirm", {}, "a"); ok(r.s === 200, "admin confirms deposit");
  r = await api("GET", "/api/me"); ok(r.j.wallet === 100000, "wallet credited 100,000");
  r = await api("POST", "/api/invest", { planId: p5.id, amount: 19999 }); ok(r.s === 400, "below plan minimum rejected");
  r = await api("POST", "/api/invest", { planId: p5.id, amount: 20000 }); ok(r.s === 200, "invest 20,000 in 5-day plan");
  const inv = (await api("GET", "/api/me")).j.investments[0]; ok(inv.interest === 40, "interest = 40 (0.2%)");
  r = await api("POST", `/api/investments/${inv.id}/collect`, {}); ok(r.s === 400, "early collect needs explicit confirmation");
  const d = new Database("test.db"); d.prepare("UPDATE investments SET maturity_ts=1").run(); d.close();
  r = await api("GET", "/api/me"); ok(r.j.wallet === 100040 && r.j.investments[0].status === "paid", "matured: credited to wallet automatically, no action needed");
  r = await api("POST", `/api/investments/${inv.id}/collect`, {}); ok(r.s === 404, "cannot collect twice");
  r = await api("POST", "/api/withdrawals", { amount: 200000, network: "MTN", phone: "0772123456" }); ok(r.s === 400, "cannot withdraw more than wallet");
  r = await api("POST", "/api/withdrawals", { amount: 100040, network: "MTN", phone: "0772123456" }); ok(r.s === 200, "withdrawal requested");
  const w = (await api("GET", "/api/admin/withdrawals?status=pending", null, "a")).j; ok(w.length === 1 && w[0].phone === "+256772123456", "admin sees payout request");
  r = await api("POST", `/api/admin/withdrawals/${w[0].id}/paid`, { ref: "PAY98765432" }, "a"); ok(r.s === 200, "admin marks payout paid");
  r = await api("POST", `/api/admin/withdrawals/${w[0].id}/paid`, { ref: "PAY98765432" }, "a"); ok(r.s === 404, "cannot pay out twice");
  r = await api("GET", "/api/admin/reconcile", null, "a"); ok(r.j.balanced && r.j.bankBook === -40 && r.j.fundingGap === 40 && r.j.owedToUsers === 0, "ledger balanced; interest funding gap = 40");
  r = await api("POST", "/api/login", { contact: "0772123456", password: "correct horse" }, "u2"); ok(r.s === 200, "password login works");

  // ---- Referral program ----
  const code = (await api("GET", "/api/me")).j.referral.code; ok(typeof code === "string" && code.length >= 6, "referrer has a referral code");
  ok((await api("GET", "/api/me")).j.referral.link === "https://example.test/?ref=" + code, "referral link built from APP_URL");
  r = await api("POST", "/api/register", { contact: "0755000111", password: "another pass1", referralCode: "BADCODE1" }, "b"); ok(r.s === 400, "invalid referral code rejected");
  r = await api("POST", "/api/register", { contact: "0755000111", password: "another pass1", referralCode: code }, "b"); ok(r.s === 200, "referred user registers with code");
  r = await api("POST", "/api/verify", { contact: "0755000111", code: otp() }, "b"); ok(r.s === 200, "referred user verified");
  await api("POST", "/api/deposits", { amount: 200000, ref: "TXB1234567" }, "b");
  const dep = (await api("GET", "/api/admin/deposits?status=pending", null, "a")).j[0];
  r = await api("POST", "/api/admin/deposits/" + dep.id + "/confirm", {}, "a"); ok(r.s === 200, "referred user's deposit confirmed");
  const p30 = plans.find(p => p.days === 30);
  const mature = () => { const d = new Database("test.db"); d.prepare("UPDATE investments SET maturity_ts=1 WHERE status='active' AND user_id=(SELECT id FROM users WHERE contact='+256755000111')").run(); d.close(); };
  await api("POST", "/api/invest", { planId: p5.id, amount: 20000 }, "b"); mature(); await api("GET", "/api/me", null, "b");
  r = await api("GET", "/api/admin/referrals", null, "a"); ok(r.j.length === 0, "5-day plan does not qualify for a commission");
  await api("POST", "/api/invest", { planId: p30.id, amount: 50000 }, "b"); mature(); await api("GET", "/api/me", null, "b");
  r = await api("GET", "/api/admin/referrals", null, "a"); ok(r.j.length === 1 && r.j[0].amount === 500 && r.j[0].status === "pending", "30-day investment matured: commission of 500 (1%) queued");
  let me = (await api("GET", "/api/me")).j; ok(me.referral.pending === 500 && me.referral.earned === 0 && me.referral.referrals[0].contact.includes("***") && !me.referral.referrals[0].contact.includes("755000111"), "referrer sees pending commission and masked referral");
  const cid = r.j[0].id;
  r = await api("POST", `/api/admin/referrals/${cid}/approve`, {}, "a"); ok(r.s === 200, "admin approves commission");
  r = await api("POST", `/api/admin/referrals/${cid}/approve`, {}, "a"); ok(r.s === 404, "commission cannot be approved twice");
  me = (await api("GET", "/api/me")).j; ok(me.wallet === 500 && me.referral.earned === 500, "commission credited to referrer wallet, withdrawable");
  await api("POST", "/api/invest", { planId: p30.id, amount: 50000 }, "b"); mature(); await api("GET", "/api/me", null, "b");
  r = await api("GET", "/api/admin/referrals", null, "a"); ok(r.j.length === 1, "only one commission per referred user");
  r = await api("GET", "/api/admin/reconcile", null, "a"); ok(r.j.balanced && r.j.referralCommissions === 500, "ledger still balanced after commission");
  console.log("\nAll checks passed.");
})().catch(e => { console.error(e); process.exit(1); });
