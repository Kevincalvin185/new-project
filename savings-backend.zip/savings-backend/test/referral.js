// Referral flow test. Server must run with DEPOSITS_ENABLED=true REFERRAL_CAP=500 DB_FILE=test.db (see README).
const fs = require("fs"), Database = require("better-sqlite3");
const B = process.env.BASE || "http://localhost:3399", jar = {};
async function api(method, path, body, who) {
  const r = await fetch(B + path, { method, headers: { "content-type": "application/json", cookie: jar[who] || "" }, body: body ? JSON.stringify(body) : undefined });
  const sc = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
  if (sc.length) jar[who] = sc.map(c => c.split(";")[0]).join("; ");
  let j = {}; try { j = await r.json(); } catch {}
  return { s: r.status, j };
}
const ok = (c, m) => { if (!c) { console.error("FAIL:", m); process.exit(1); } console.log("ok  ", m); };
const otp = () => fs.readFileSync("server.log", "utf8").split("\n").filter(x => x.includes("[DEV OTP]")).pop().split(": ").pop().trim();
const signup = async (who, contact, code) => { let r = await api("POST", "/api/register", { contact, password: "correct horse", referralCode: code }, who); if (r.s !== 200) return r; return api("POST", "/api/verify", { contact, code: otp() }, who); };
let n = 0;
const fund = async (who, amount) => { await api("POST", "/api/deposits", { amount, ref: "FUND" + (++n) + "ABCDEF" }, who); const d = (await api("GET", "/api/admin/deposits?status=pending", null, "a")).j; await api("POST", `/api/admin/deposits/${d[0].id}/confirm`, {}, "a"); };
const mature = () => { const d = new Database("test.db"); d.prepare("UPDATE investments SET maturity_ts=1 WHERE status='active'").run(); d.close(); };
(async () => {
  await api("POST", "/api/admin/login", { username: "kevin", password: "admin-test-password-123" }, "a");
  let r = await signup("A", "0772000001"); ok(r.s === 200, "referrer A signs up");
  const codeA = (await api("GET", "/api/me", null, "A")).j.referral.code; ok(/^[A-Z2-9]{8}$/.test(codeA), "A has a referral code");
  r = await signup("X", "0772000009", "BADCODE12"); ok(r.s === 400, "invalid referral code rejected");
  r = await signup("B", "0772000002", codeA); ok(r.s === 200, "B signs up with A's code");
  r = await signup("C", "0772000003", codeA); ok(r.s === 200, "C signs up with A's code");
  let ref = (await api("GET", "/api/me", null, "A")).j.referral; ok(ref.referrals.length === 2 && ref.referrals[0].contact.includes("***"), "A sees 2 masked referrals");
  const plans = (await api("GET", "/api/plans")).j, p5 = plans.find(p => p.days === 5), p30 = plans.find(p => p.days === 30);
  // C only does a short plan: no commission
  await fund("C", 20000); await api("POST", "/api/invest", { planId: p5.id, amount: 20000 }, "C"); mature(); await api("GET", "/api/me", null, "C");
  ok((await api("GET", "/api/admin/referrals", null, "a")).j.length === 0, "5-day plan matured: no commission");
  // B invests in a 30-day plan: commission only after maturity
  await fund("B", 100000); await api("POST", "/api/invest", { planId: p30.id, amount: 100000 }, "B");
  ok((await api("GET", "/api/admin/referrals", null, "a")).j.length === 0, "no commission while the plan is still running");
  mature(); await api("GET", "/api/me", null, "B");
  let list = (await api("GET", "/api/admin/referrals", null, "a")).j; ok(list.length === 1 && list[0].status === "pending" && list[0].amount === 500, "matured 30-day plan: pending commission, capped at 500 (1% would be 1,000)");
  ref = (await api("GET", "/api/me", null, "A")).j.referral; ok(ref.pending === 500 && ref.earned === 0, "A sees 500 pending, 0 earned");
  r = await api("POST", `/api/admin/referrals/${list[0].id}/approve`, {}, "a"); ok(r.s === 200, "admin approves commission");
  const me = (await api("GET", "/api/me", null, "A")).j; ok(me.wallet === 500 && me.referral.earned === 500, "A wallet credited 500");
  r = await api("POST", `/api/admin/referrals/${list[0].id}/approve`, {}, "a"); ok(r.s === 404, "cannot approve twice");
  // second qualifying investment by B pays nothing more
  await fund("B", 100000); await api("POST", "/api/invest", { planId: p30.id, amount: 100000 }, "B"); mature(); await api("GET", "/api/me", null, "B");
  ok((await api("GET", "/api/admin/referrals", null, "a")).j.length === 1, "only one commission per referee");
  ok((await api("GET", "/api/admin/referral-links", null, "a")).j.length === 2, "admin sees who referred whom");
  r = await api("GET", "/api/admin/reconcile", null, "a"); ok(r.j.balanced && r.j.referralCommissions === 500, "ledger balanced; referral expense recorded");
  r = await api("GET", "/api/admin/referrals", null, "A"); ok(r.s === 401, "users cannot reach referral admin");
  console.log("\nAll referral checks passed.");
})().catch(e => { console.error(e); process.exit(1); });
