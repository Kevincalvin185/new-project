// Usage: npm run hash -- "your-admin-password"   (prints a bcrypt hash for ADMIN_PASS_HASH)
const bcrypt = require("bcryptjs");
const pw = process.argv[2];
if (!pw || pw.length < 12) { console.error("Give a password of at least 12 characters."); process.exit(1); }
bcrypt.hash(pw, 12).then(h => console.log(h));
